Version 4
SymbolType CELL
LINE Normal 12 -6 -8 0
LINE Normal -8 0 12 6
LINE Normal 5 0 12 6
LINE Normal 12 -6 5 0
